using Godot;
using System;

public partial class Hud : Control
{
	// Write a script that takes current gun stats and displays them in bottom right, add a function that will get called when shooting at the player script to update these values, also call it on reload, thanks
	public override void _Ready()
	{
		
	}
}
